import Head from 'next/head'
import styles from '../styles/Styles.module.css'
import Link from 'next/link'

export default function Home() {
  return (
    <div className={styles.container}>
      <Head>
        <title>My Next App</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <body>
        <main className={styles.main}>
        <div className={styles.aboutme}>
        <Link href="/about_me">
          about me </Link>
        </div>
        <div className={styles.weather}>
        <Link href="/weather">
          weather </Link>
        </div>
        </main>

        <footer>
        </footer>
      </body>
    </div>
  )
}
