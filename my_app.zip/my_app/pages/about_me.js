import Head from 'next/head'
import Image from 'next/image'
import { useState } from 'react'
//import styles from '../styles/Home.module.css'
import styles from '../styles/Styles.module.css'
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import 'fontsource-roboto';

const useStyles= makeStyles({
  TypoStyle:{
    color:"pink"
  }
});


export default function Home() {
  const [fullName, setFullName] = useState(false);
  const full="Hizkia Raditya Pratama Roosadi"
  const short="Hizkia"
  const matUI=useStyles();
  function handleClickFullName(){
    if (fullName==false) {
      setFullName(true)} 
    else {
      setFullName(false)
    }
  }
  return (
    <div className={styles.container}>
      <Head>
        <title>My Next App</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <body>
        <main className={styles.main}>
          <h1 className={styles.h1}>About me</h1>
          <h2 className={styles.h2}>I am an Informatics Student at ITB</h2>
          <div style={{display: "flex",justifyContent: "center",}}>
          <Image
            src="/../public/mypic.png"
            alt="Picture of the author"
            width={300}
            height={300}
          />
          </div>
          <h2 className={styles.myname}>{fullName ? full : short}</h2>
          <h2 className={styles.myemail}>hizradit07@gmail.com</h2>
          <div style={{display: "flex",justifyContent: "center",}}>
          <Button variant="contained" color="primary" onClick={ handleClickFullName }>change name</Button>
          </div>
        </main>

        <footer>
        <div style={{display: "flex",justifyContent: "center",}}>
        <Typography className={matUI.TypoStyle} variant="h3" component="h3">
          I am using typography here
        </Typography>
        </div>
        </footer>
      </body>
    </div>
  )
}
