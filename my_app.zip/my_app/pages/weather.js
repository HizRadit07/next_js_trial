import Head from 'next/head'
import styles from '../styles/Styles.module.css'


export default function Home() {
    fetch ('http://api.weatherstack.com/current?access_key=1b86fa294f9b1aa5113b4d9cc35c1ec8&query=New%20York')
        .then(res =>res.json())
        .then(data =>console.log(data))
    
    return (
        <div className={styles.container}>
          <Head>
            <title>My Next App</title>
            <link rel="icon" href="/favicon.ico" />
          </Head>
          <body>
  
          </body>
        </div>
    )
}